"""Bills model — tenant schema. Mirrors estate_management_BE."""

from sqlalchemy import Column, String, Float, DateTime, ForeignKey, Enum, Integer
from sqlalchemy.orm import relationship
import enum

from api.v1.models.base_model import BaseTableModel


class BillStatus(str, enum.Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    CLOSED = "closed"
    CANCELLED = "cancelled"


class Bill(BaseTableModel):
    """Estate bills — tenant schema."""

    __tablename__ = "bills"

    user_id = Column(String, ForeignKey("users.id"), nullable=True, index=True)
    title = Column(String(200), nullable=False)
    description = Column(String, nullable=True)
    amount = Column(Float, nullable=False)
    due_date = Column(DateTime(timezone=True), nullable=True)
    status = Column(Enum(BillStatus), default=BillStatus.ACTIVE, index=True)
    bill_type = Column(String(50), nullable=True)  # "security_levy", "electricity", etc.
    total_expected = Column(Integer, default=0)
    total_paid = Column(Integer, default=0)

    # Relationships
    user = relationship("User", back_populates="bills")
    resident_bills = relationship("ResidentBill", back_populates="bill", cascade="all, delete-orphan")
