"""Subscription model — public schema.

CORRECTED: Now properly connected to Estate via FK relationship.
Tracks SaaS subscription status, billing, and plan features.
"""

from sqlalchemy import Column, String, Float, DateTime, Integer, Boolean
from sqlalchemy.dialects.postgresql import JSONB

from api.v1.models.base_model import BaseTableModel


class Subscription(BaseTableModel):
    """SaaS subscription records — public schema."""

    __tablename__ = "subscriptions"

    # ── Who owns this subscription ──
    entity_type = Column(
        String(20), nullable=False, index=True,
        comment="estate | firm",
    )
    entity_id = Column(String, nullable=False, index=True)

    # ── Plan Details ──
    plan = Column(
        String(50), nullable=False,
        comment="trial | basic | standard | premium | enterprise",
    )
    status = Column(
        String(20), default="trial", index=True,
        comment="trial | active | past_due | expired | cancelled",
    )

    # ── Dates ──
    trial_ends_at = Column(DateTime(timezone=True), nullable=True)
    started_at = Column(DateTime(timezone=True), nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=True)
    cancelled_at = Column(DateTime(timezone=True), nullable=True)

    # ── Billing ──
    paystack_subscription_code = Column(String(100), nullable=True)
    paystack_customer_code = Column(String(100), nullable=True)
    paystack_plan_code = Column(String(100), nullable=True)
    amount_ngn = Column(Float, nullable=True)
    billing_cycle = Column(
        String(20), default="monthly",
        comment="monthly | quarterly | yearly",
    )

    # ── Plan Features / Limits ──
    max_houses = Column(
        Integer, nullable=True,
        comment="Max houses allowed on this plan (null = unlimited)",
    )
    max_staff = Column(
        Integer, nullable=True,
        comment="Max staff accounts allowed",
    )
    features = Column(
        JSONB, nullable=True,
        comment='Enabled features: {"chat": true, "vote": true, "expenses": false}',
    )

    # ── Auto-renewal ──
    auto_renew = Column(Boolean, default=True)
    renewal_reminder_sent = Column(Boolean, default=False)

    def is_active_or_trial(self) -> bool:
        return self.status in ("trial", "active")

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        from datetime import datetime, timezone
        return datetime.now(timezone.utc) > self.expires_at
